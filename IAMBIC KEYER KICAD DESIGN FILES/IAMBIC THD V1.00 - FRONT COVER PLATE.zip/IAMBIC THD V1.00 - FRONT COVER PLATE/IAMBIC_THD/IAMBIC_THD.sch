EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title "CAPACITIVE TOUCH IAMBIC KEYER"
Date ""
Rev "V1.0"
Comp "WB2CBA"
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Mechanical:MountingHole_Pad H1
U 1 1 6811B747
P 2850 5300
F 0 "H1" H 2950 5349 50  0000 L CNN
F 1 "MountingHole_Pad" H 2950 5258 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_DIN965" H 2850 5300 50  0001 C CNN
F 3 "~" H 2850 5300 50  0001 C CNN
	1    2850 5300
	1    0    0    -1  
$EndComp
$Comp
L Mechanical:MountingHole_Pad H2
U 1 1 6811C564
P 2850 5800
F 0 "H2" H 2950 5849 50  0000 L CNN
F 1 "MountingHole_Pad" H 2950 5758 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_DIN965" H 2850 5800 50  0001 C CNN
F 3 "~" H 2850 5800 50  0001 C CNN
	1    2850 5800
	1    0    0    -1  
$EndComp
$Comp
L Mechanical:MountingHole_Pad H4
U 1 1 6811CD03
P 3750 5850
F 0 "H4" H 3850 5899 50  0000 L CNN
F 1 "MountingHole_Pad" H 3850 5808 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_DIN965" H 3750 5850 50  0001 C CNN
F 3 "~" H 3750 5850 50  0001 C CNN
	1    3750 5850
	1    0    0    -1  
$EndComp
$Comp
L power:GNDPWR #PWR0110
U 1 1 6811D289
P 2850 5400
F 0 "#PWR0110" H 2850 5200 50  0001 C CNN
F 1 "GNDPWR" H 2854 5246 50  0000 C CNN
F 2 "" H 2850 5350 50  0001 C CNN
F 3 "" H 2850 5350 50  0001 C CNN
	1    2850 5400
	1    0    0    -1  
$EndComp
$Comp
L power:GNDPWR #PWR0112
U 1 1 6811E49A
P 2850 5900
F 0 "#PWR0112" H 2850 5700 50  0001 C CNN
F 1 "GNDPWR" H 2854 5746 50  0000 C CNN
F 2 "" H 2850 5850 50  0001 C CNN
F 3 "" H 2850 5850 50  0001 C CNN
	1    2850 5900
	1    0    0    -1  
$EndComp
$Comp
L power:GNDPWR #PWR0113
U 1 1 6811EB01
P 3750 5950
F 0 "#PWR0113" H 3750 5750 50  0001 C CNN
F 1 "GNDPWR" H 3754 5796 50  0000 C CNN
F 2 "" H 3750 5900 50  0001 C CNN
F 3 "" H 3750 5900 50  0001 C CNN
	1    3750 5950
	1    0    0    -1  
$EndComp
$Comp
L power:GNDPWR #PWR0111
U 1 1 6811DD2C
P 3750 5400
F 0 "#PWR0111" H 3750 5200 50  0001 C CNN
F 1 "GNDPWR" H 3754 5246 50  0000 C CNN
F 2 "" H 3750 5350 50  0001 C CNN
F 3 "" H 3750 5350 50  0001 C CNN
	1    3750 5400
	1    0    0    -1  
$EndComp
$Comp
L Mechanical:MountingHole_Pad H3
U 1 1 6811BCFC
P 3750 5300
F 0 "H3" H 3850 5349 50  0000 L CNN
F 1 "MountingHole_Pad" H 3850 5258 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_DIN965" H 3750 5300 50  0001 C CNN
F 3 "~" H 3750 5300 50  0001 C CNN
	1    3750 5300
	1    0    0    -1  
$EndComp
$EndSCHEMATC
